#!/bin/bash
echo "Starting D&D Stat Wheel Discord Bot..."
node bot.js